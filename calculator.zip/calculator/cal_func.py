def cal(num1,num2,operation):

    num1=float(num1)
    num2=float(num2)
    if operation == "+":
      result = num1 + num2
    elif operation == "-":
      result = num1 - num2
    elif operation == "/":
      result = num1 / num2
    elif operation == "*":
      result = num1 * num2
    else:
      result = "Operations supported: add, subtract, divide, multiple only"

    return result