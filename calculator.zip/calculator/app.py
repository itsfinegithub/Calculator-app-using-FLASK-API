from flask import Flask, request, render_template
from pymongo import MongoClient

app = Flask(__name__)
from cal_func import cal

client = MongoClient('localhost',port= 27017)
db = client.calculator
coll = db.user_records


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():

    num1 = request.form['num1']
    num2 = request.form['num2']
    operation = str(request.form['operation'])

    result = cal(num1,num2,operation)
    records = {
        'num1':num1,
        'num2':num2,
        'operation':operation,
        'calculate': result
    }
    coll.insert_one(records)

    return render_template('index.html', result=str(result))


if __name__ == "__main__":
    app.run(debug=True)